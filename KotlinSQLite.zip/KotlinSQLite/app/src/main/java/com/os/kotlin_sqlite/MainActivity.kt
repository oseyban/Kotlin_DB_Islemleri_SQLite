package com.os.kotlin_sqlite

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    @SuppressLint("SQLiteString", "Recycle")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            val db=this.openOrCreateDatabase("Musteriler", MODE_PRIVATE,null)

            //tablo oluşturma işlemi
            db.execSQL("CREATE TABLE IF NOT EXISTS musteriler(id INTEGER PRIMARY KEY, ad TEXT, tel TEXT, dogum DATE)")

            //ekleme işlemi
            //db.execSQL("INSERT INTO musteriler(ad,tel,dogum) VALUES('Osman','11116435763','1.1.1111')")
            //db.execSQL("INSERT INTO musteriler(ad,tel,dogum) VALUES('Osman2','2226435763','2.2.2222')")
            //db.execSQL("INSERT INTO musteriler(ad,tel,dogum) VALUES('Osman3','33316435763','3.3.3333')")

            //filtreleme işlemi
            //val cursor=db.rawQuery("select * FROM musteriler", null)
            //val cursor=db.rawQuery("select * FROM musteriler WHERE ad='Osman2'", null)
            //val cursor=db.rawQuery("select * FROM musteriler WHERE ad='Osman2' LIKE '%m%'", null)

            //silme işlemi
            //db.execSQL("DELETE FROM urunler WHERE id=0")

            //güncelleme işlemi
            db.execSQL("UPDATE urunler SET ad='Mehmet' WHERE id=1")


            val idColumnIndex=cursor.getColumnIndex("id")
            val adColumnIndex=cursor.getColumnIndex("ad")
            val telColumnIndex=cursor.getColumnIndex("tel")
            val dogumColumnIndex=cursor.getColumnIndex("dogum")

            while(cursor.moveToNext()){
                println("ID : ${cursor.getInt(idColumnIndex)}")
                println("AD : ${cursor.getString(adColumnIndex)}")
                println("TEL : ${cursor.getString(telColumnIndex)}")
                println("DOĞUM : ${cursor.getString(dogumColumnIndex)}")
            }
        }catch(e:java.lang.Exception){
            e.printStackTrace()
        }
    }
}